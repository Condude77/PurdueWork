#include <iostream>

using namespace std;

int main(){
  cout << -5 % 2 << "\n";
}
