#!/usr/bin/perl

$mod = -5%2;
print "$mod\n";
