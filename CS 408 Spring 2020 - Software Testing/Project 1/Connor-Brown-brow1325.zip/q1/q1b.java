class Q1b{
  public static  void main(String[] args){
    System.out.println(-5%2);
  }
}
